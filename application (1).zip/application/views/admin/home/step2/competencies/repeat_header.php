
<div class="add-title"><b>Core Competencies</b>
    <button type="button" class="remove-btn" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i>X</button>
</div>